package com.gargi.functionalinterfaceexample;

public class FunctionalInterfaceExample{

	public static void main(String[] args) {
		// Using lambda expression
        Calculator addition = (a, b) -> a + b;
        int result = addition.calculate(10, 5);
        System.out.println("Addition Result: " + result);

        // Using anonymous inner class
        Calculator subtraction = new Calculator() {
            @Override
            public int calculate(int a, int b) {
                return a - b;
            }
        };
        result = subtraction.calculate(10, 5);
        System.out.println("Subtraction Result: " + result);
	}

}
