package com.gargi.functionalinterfaceexample;

@FunctionalInterface
public interface Calculator {
	int calculate(int a, int b);

}
