package com.gargi.interfaceexample;

public interface Animal {
	 void eat();
	 void sleep();

}
