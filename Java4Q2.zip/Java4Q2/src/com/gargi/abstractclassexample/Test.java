package com.gargi.abstractclassexample;

public class Test {

	public static void main(String[] args) {
		 Shape rectangle = new Rectangle(5, 3);
	        rectangle.draw();
	        rectangle.display();
	        rectangle.printArea();

	        Shape circle = new Circle(2.5);
	        circle.draw();
	        circle.display();
	        circle.printArea();
	}

}
