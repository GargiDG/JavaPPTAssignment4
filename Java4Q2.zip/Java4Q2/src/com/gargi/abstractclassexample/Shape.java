package com.gargi.abstractclassexample;

//Abstract class
abstract class Shape {
 // Abstract methods
 public abstract void draw();
 public abstract double calculateArea();

 // Concrete methods
 public void display() {
     System.out.println("Displaying shape.");
 }

 public void printArea() {
     double area = calculateArea();
     System.out.println("Area: " + area);
 }
}